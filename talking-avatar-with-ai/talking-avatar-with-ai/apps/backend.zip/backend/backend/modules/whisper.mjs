import OpenAI from "openai";
import { convertAudioToMp3 } from "../utils/audios.mjs";
import fs from "fs";
import path from "path";
import dotenv from "dotenv";
dotenv.config();

const openAIApiKey = process.env.OPENAI_API_KEY;

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: openAIApiKey,
});

async function convertAudioToText({ audioData, language }) {
  // Convert base64 to buffer if it's a string
  let audioBuffer;
  if (typeof audioData === 'string') {
    // Assume it's base64 encoded
    audioBuffer = Buffer.from(audioData, 'base64');
  } else {
    audioBuffer = audioData;
  }

  const mp3AudioData = await convertAudioToMp3({ audioData: audioBuffer });
  const tmpDir = path.join(process.cwd(), 'tmp');
  if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir, { recursive: true });
  }
  const outputPath = path.join(tmpDir, "output.mp3");
  fs.writeFileSync(outputPath, mp3AudioData);
  
  try {
    // Create a File object for the OpenAI API
    const audioFile = fs.createReadStream(outputPath);
    
    // Prepare transcription options
    const transcriptionOptions = {
      file: audioFile,
      model: "whisper-1",
    };
    
    // Add language parameter if provided
    if (language) {
      transcriptionOptions.language = language;
    }
    
    // Transcribe audio using OpenAI Whisper API
    const transcription = await openai.audio.transcriptions.create(transcriptionOptions);
    const transcribedText = transcription.text;
    
    // Clean up temp file
    fs.unlinkSync(outputPath);
    
    return transcribedText;
  } catch (error) {
    // Clean up temp file on error
    if (fs.existsSync(outputPath)) {
      fs.unlinkSync(outputPath);
    }
    throw error;
  }
}

export { convertAudioToText };
